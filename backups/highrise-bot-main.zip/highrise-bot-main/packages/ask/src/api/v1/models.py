# Define your database models for API v1 here
