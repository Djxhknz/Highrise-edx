# Define your database models for API v2 here
