# This directory is for external plugin commands.
# Place your custom command .py files here. Each should define a Command class, just like built-in commands.